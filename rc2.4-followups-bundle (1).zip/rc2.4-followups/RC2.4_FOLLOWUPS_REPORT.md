# GetDaNet RC2.4 — follow-up items 5–8 (2026-10-05)

Baseline untouched: `GetDaNet-v3_0-RC2_4.zip`, SHA-256 `7460dc9c6e7966a21179f0758a4d26b12fe2640067300de593ffe29d7a4bba2c`. No source file in that zip was changed. The only change produced here is a TEST-HARNESS patch (`chromium-e2e-harness.patch`), delivered separately so the CI baseline hash stays valid. Apply it after the first CI run.
Labels: SC source-checked · AT automated-test (local, one machine) · CI · DV device · RW real-world.

## Still blocked (need GitHub / devices)
Items 1–4 (push, five-job CI, CI fixes, adding integration suites to CI) and 9 (final report) cannot be done without GitHub access. Nothing here is CI-verified.

## 5. Android frontend delivery and Ed25519 (SC)
- The Android app is native Kotlin. No WebView, `loadUrl`, Custom Tabs, TWA, Capacitor/Cordova or bundled web assets exist in `android/app/src` or `build.gradle.kts`. The frontend is NOT embedded in the APK.
- Android Ed25519 does not use browser WebCrypto: `IdentityStore.kt` uses BouncyCastle `Ed25519PrivateKeyParameters` (`org.bouncycastle:bcprov-jdk18on:1.85.2`, a real Maven Central release per search results). Same wire format as the web client (SPKI/DER, raw 64-byte signature) per comments in `frontend/src/lib/getdanet/identity.ts`.
- Browser WebCrypto Ed25519 is used only by the web frontend (`identity.ts` lines 105, 114, 143). Chrome for Testing 131 needed `--enable-experimental-web-platform-features`. So the limitation applies to the web UI in browsers/WebViews lacking Ed25519, not to the Android production path as currently written. Minimum browser versions supporting it by default were not verified here.
- Not verified on a device: BouncyCastle Ed25519 on Android, `minSdk` is 26 (the task text said API 29+ for testing; the manifest minimum is lower).
- Recommendation: no code change. If the web UI is ever to be shipped inside the app, test enrollment on the oldest supported WebView first.

## 6. Google Fonts (SC + AT)
- `frontend/src/routes/__root.tsx` lines 91–95 load Plus Jakarta Sans from `fonts.googleapis.com` / `fonts.gstatic.com` at runtime. Production does depend on a remote font CDN (privacy: viewers' IPs reach Google; offline: falls back to system fonts).
- The two 403s in the e2e run are exactly that stylesheet request, one per tab, at page load (captured by URL). Classified expected-environmental. Optional later improvement: self-host the font. Not changed.

## 7. E2E harness cleanup (AT, patch provided, revision 2)
Root cause of the orphan: the harness started Vite via `npx`, and `frontend.kill()` signalled only the `npx` wrapper. It also had no cleanup if the test threw. Patch: each server runs in its own process group, teardown kills the group, an `exit` hook kills any survivors, `CHROME_PATH` env override added (default unchanged).
Failure classification (revision 2, after review feedback): a failure is "expected" ONLY when its URL is positively identified as a known font CDN host (`fonts.googleapis.com`, `fonts.gstatic.com`). Both HTTP >=400 responses AND no-response failures (`requestfailed`: DNS, refused, aborted) are tracked. Console errors are matched by the resource URL carried on the console message itself; pageerrors and anything without a positively identified font-CDN URL are UNEXPECTED. Unexpected items are reported but do NOT fail the run (pass/fail criteria are unchanged; make them fail later if you want that).
Evidence (processes counted via `ps` for `vite dev` / `broker-server.js`):
- original harness, normal passing run: 1 orphan Vite process left (reproduced);
- patched, normal run: rc 0, 0 processes left; 13/13 steps PASS; 4 failed requests (per tab: the font stylesheet 403 and an aborted duplicate of the same request), all font CDN = expected, 0 unexpected; 2 console errors, both expected;
- patched, forced failure (nonexistent Chrome after servers started): rc 1, 0 processes left, immediately and after 3 s;
- mutation (temporary copy injecting a request to `nonexistent-host-getdanet.invalid`): flagged UNEXPECTED as a no-response network failure AND as an UNEXPECTED console error; the previous version of the filter would have labelled that console line accounted-for. Run exited 0 because classification only reports.
The patch applies cleanly to pristine RC2.4, and the patched pristine file is byte-identical to the harness that was tested. Logs: `logs/` (current), `logs-v1-superseded/` (first revision, kept for traceability).


### 7b. Revision 3 — unexpected failures now fail the run (AT; apply only AFTER the pristine-baseline CI run)
Delivered as two separate commits-in-waiting so effects are attributable: `0001-chromium-e2e-harness-rev2.patch` (cleanup + classification, reports only) then `0002-chromium-e2e-fail-on-unexpected-rev3.patch` (any UNEXPECTED network failure or console/page error makes the run exit non-zero). Both apply in order to pristine RC2.4; the result is byte-identical to the tested harness. No RC2.4 source file was touched.
Results (logs in `logs/`, files `chromium-e2e-rev3-*.log`; processes counted via `ps`):
- normal run: rc 0, 13/13 steps PASS (plus the final summary PASS line), 0 UNEXPECTED, 0 processes left;
- injected request to a nonexistent host: UNEXPECTED (network no-response failure and console error), rc 1;
- injected page error: UNEXPECTED (pageerror without a font-CDN URL), rc 1;
- forced Chrome startup failure: rc 1;
- 0 vite/broker processes left after all four runs (checked +3 s).
Expected failures remain ONLY those positively identified as `fonts.googleapis.com` / `fonts.gstatic.com`. Caveat: in an environment where the font CDN is reachable the font entries simply won't appear; in one where other external resources are blocked (e.g. a corporate proxy) the run will now fail on them, which is the intended behavior.

## 8. NG-01 → NG-09 audit (source + the RC2.4 clean-extraction `test:all` run, exit 0)
There is no standalone NG checklist in the repo; the NG labels come from `docs/nextgen/ARCHITECTURE_CONTRACT.md` and code/test annotations. Status below is per what is demonstrably present and run.
| NG | Subject | Status | Supporting evidence |
|---|---|---|---|
| 01 | Architecture contract | VERIFIED (SC, document only) | `docs/nextgen/ARCHITECTURE_CONTRACT.md` present, referenced by NG-02..04 modules; nothing executable |
| 02 | Network intelligence / live health | VERIFIED (AT) | `test/network-intelligence-v2.js` 34/34; wired in `broker-server.js` (attachHealthTracking, recordConnectionClosed) |
| 03 | Multi-connectivity (TransportProvider) | VERIFIED (AT) | `test/multi-connectivity.js` 27/27 |
| 04 | Automatic failover | VERIFIED (AT) | `test/automatic-failover.js` 27/27 |
| 05 / 05.1 | Advanced accounting; stream-id isolation | VERIFIED (AT) | `test/advanced-accounting.js` 36/36; `test/stream-isolation.js` 15/15 |
| 06 | Community node | VERIFIED (AT) | `test/community-node.js` 111/111 |
| 07 | Pod | VERIFIED (AT) | `test/getdanet-pod.js` 70 passed, 0 failed, 0 blocked |
| 08 | Experimental mesh (isolated) | VERIFIED (AT + SC) | `test/experimental-mesh.js` 62/62. Independent check: nothing in `backend/`, `frontend/src`, `android/app/src`, `scripts/` or `.github/` imports `mesh-experimental/` except `backend/test/experimental-mesh.js`, which itself asserts the isolation |
| 09 | Operator research | N/A for execution (SC, document only) | `docs/nextgen/NETWORK_OPERATOR_RESEARCH.md`; contract §7 says NG-09 has no interface |
Limits: all AT results are local, same-machine runs; none is device- or real-network-verified. NG-02..04 behavior was tested with synthetic/fake transports in places (per test comments), not real carrier failover. "Verified" here means those suites pass on RC2.4, not that the NG goals are proven on phones.

## Notes for CI
`minSdk` 26, `compileSdk`/`targetSdk` 35. Remaining likely first CI failures are unchanged: native step (Go 1.26.3 + NDK) and first-ever compile of `GetDaNetVpnService.kt`.
