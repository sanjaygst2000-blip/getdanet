# GetDaNet RC2.4 — security fix, harness and CI patches: final verification report (2026-10-05)

Scope: direct-mode security fix (0003), Chromium harness (0001, 0002), integration CI job (0004). Everything below was executed in ONE Linux sandbox (real processes, loopback between them). **No GitHub Actions run, Android build, APK, emulator/device run, or two-device test exists.** Labels: **VERIFIED LOCALLY** (executed here, evidence in `final-verification-evidence/`), **SOURCE-REVIEWED**, **BLOCKED**, **FAILED**. Local results are never GitHub-hosted CI results.

## 1. Identity and hashes
| Artifact | SHA-256 |
|---|---|
| Pristine source `GetDaNet-v3_0-RC2_4.zip` (unaltered) | `7460dc9c6e7966a21179f0758a4d26b12fe2640067300de593ffe29d7a4bba2c` |
| `0001-chromium-e2e-harness-rev2.patch` | `a391cf508bafb6d227a035317bff9b2caac11f8504dafb3874cdfefe07bf7cbe` |
| `0002-chromium-e2e-fail-on-unexpected-rev3.patch` | `094bba86a131f3815185f862ed5563deec2a584e4fb168e9508d1937e1ef3f8d` |
| `0003-direct-mode-disabled-in-production.patch` | `8bb77b3f13b5f2a7f9640caa9ed52bc9e454f126b4562ec3f319ac1e6b917fa2` |
| `0004-ci-add-integration-job.patch` | `2305bbc2acde81981ee08f42029c842f9bdf49cf51a5db5aeb69f8d3fdb0246d` |
| `getdanet-rc2.4-with-fixes.gitbundle` | `c577d043f6c477188548724198455dfaa042e6cb17a14cfacb4f570b7ad36618` |

The follow-up bundle ZIP's own hash cannot be written inside itself; it is in `SHA256SUMS-RC2.4-followups.txt` next to it and in the hand-off message.

## 2. Local commits (NOT pushed anywhere — GitHub access BLOCKED)
Built from the pristine zip with a fixed identity; one patch per commit; `git apply --check` before each; the tracked leak scan was clean (only `android/keystore.properties.example`, a template; real keystore files are git-ignored).

| Commit | Tag | Change | Files |
|---|---|---|---|
| `13dcce1fef5f82ad6b1ca5f5dacbee58eb706a99` | `baseline-rc2.4-pristine` | pristine RC2.4 (379 tracked files, every one byte-equal to the zip) | - |
| `8ca1673fcc235545fbe9a52f963c35f448b3e492` | `fix-0003-direct-mode` | 0003 | backend/shared.js, broker-server.js, client-a.js, package.json, test/direct-mode-gate.js |
| `f2041109a4410ff6e8cf8bd1522d95360a94cc49` | - | 0001 | integration-tests/chromium-e2e.mjs |
| `8a42873a91fad40338377cc393f3a17012c03cda` | `harness-0001-0002` | 0002 | integration-tests/chromium-e2e.mjs |
| `a3b206a110111f83a7648d4af42b92093fbfe2fa` | `ci-0004-integration` | 0004 | .github/workflows/production.yml |

`git bundle verify` passes; a clone from the bundle matches the repository (380 tracked files, 0 differing). The zip holds 4 extra git-ignored generated files (`frontend/.unit-build/*`, `frontend/.wrangler/deploy/config.json`) that the baseline commit correctly omits. Commit SHAs depend on the fixed author/date used here; pushing the bundle preserves them exactly.

Patch integrity: 0003 regenerated from the final verified tree is byte-identical to the shipped patch; dry-run and real apply on a fresh pristine copy succeed; the 5 modified files are byte-identical to the verified working tree; all four patches compose cleanly. **VERIFIED LOCALLY.**

## 3. Direct-mode security (0003)
### 3.1 The vulnerability on PRISTINE RC2.4 — FAILED (reproduced from a fresh extraction)
Real broker, real provider, raw requester with its own identity (invite redeemed, trust active); `direct-request` -> `direct-ready 127.0.0.1:<port>`; requester downloads the Linux tarball through the broker-bypassing direct stream.
- REVOKE issued at ~5.7 s: stream continued to 15.6 s; 26.2 MB at the revoke, 88.6 MB final -> **62 MB delivered after revoke**.
- STOP_ALL_SHARING at ~5.7 s: 25.7 MB at the command, 86.3 MB final -> **61 MB after the command**.
Earlier runs showed the same behaviour with different totals. Broker logs confirmed `trust ... revoked` / `STOP ALL SHARING ... revoked`.

### 3.2 Controls on the fixed source (fresh patched copy; commands and exit codes in `final-verification-evidence/`)
| # | Check | Result |
|---|---|---|
| 1 | Real broker, `GETDANET_ENV=production`, no override: `direct-request` | `{"type":"direct-fail","message":"direct mode is disabled on this broker"}`; **no** warning emitted - VERIFIED LOCALLY |
| 2 | Real production broker with `GETDANET_ENABLE_DIRECT_MODE=true` | reply `no providers online` (gate open); startup line: `WARNING: direct mode is ENABLED in production ... REVOKE, STOP ALL SHARING, session/data limits and accounting do NOT apply to them.` Each of the four terms verified present (session limit = duration, data limit = usage) - VERIFIED LOCALLY |
| 3 | Real `client-a.js` receives `direct-listen` from a fake broker with direct mode disabled | answers `direct-fail` "disabled", never opens a listener - VERIFIED LOCALLY |
| 4 | Positive control, explicitly enabled | real provider opens the listener and answers `direct-ready` - VERIFIED LOCALLY |
| 5 | Mutations in a disposable copy (restored byte-identical after each): remove broker gate / provider gate / startup warning | each makes `test/direct-mode-gate.js` exit 1 (the provider mutation leaks a real `direct-ready`); restored tree 15/15 PASS - VERIFIED LOCALLY |
| 6 | Replay of the revoke exploit against the fixed code | dev broker with `GETDANET_ENABLE_DIRECT_MODE=false`: `direct-request refused: direct mode is disabled on this broker`, provider never told to listen - VERIFIED LOCALLY. The full exploit in PRODUCTION mode was NOT replayed (needs production enrollment of a real provider); the live production-mode refusal (row 1) happens before provider selection - SOURCE-REVIEWED that nothing later can run |

`test/direct-mode-gate.js` has **15 checks**, run on commit `8ca1673` in a clean worktree: exit 0. Stage 4 regression PASS and stream-isolation PASS on the same commit (direct mode still works when enabled outside production).

### 3.3 Backend suite — VERIFIED LOCALLY
Fresh copy of pristine + 0003, no pre-existing certs or state: `npm ci` exit 0; `npm run test:all` **EXIT=0** in 158 s. Authoritative result = exit code plus per-suite summaries: the 12 suites that print `Summary: N passed, M failed` total **433 passed, 0 failed, 0 blocked**; the remaining suites print one `PASS` line per check and no summary line, so there is no single runner total. No failure markers, no `EADDRINUSE`. The "PASS markers" figure is only a count of log lines containing `PASS` or `✅`: **559** (RC2.4 without any gate test) -> **567** (first 8-check version) -> **574** (final 15-check version; the clean-state run also gives 574). The differences are exactly the new test's PASS lines. Backend files are unchanged between 0003 and the final commit, so this result applies to it. No broker/provider/vite process remained after the runs.

**Side finding (low, OPEN, hygiene):** `backend/pod-config.json` is tracked and the pod test rewrites it (absolute paths, identity fingerprint), so a full suite run dirties the tracked tree; the pristine zip also ships it with another machine's absolute paths. No secret is involved (a public-key fingerprint). Not changed (unrelated logic); suggest untracking and git-ignoring it.

### 3.4 Remaining gap — the explicit override
`GETDANET_ENABLE_DIRECT_MODE=true` still re-opens a known authorization-control gap in production by design; it is now explicit (exact string `true`) and loudly logged, not blocked. **Recommendation:** make the broker refuse to start when production and the override are both set, until direct streams implement and test REVOKE, STOP_ALL_SHARING, duration/usage limits and accounting. Not implemented (not requested); easy to add with a test.
Direct mode as written also binds the provider listener to `127.0.0.1`, so it cannot carry traffic between two devices (SOURCE-REVIEWED). No local test here is evidence of cross-device connectivity.

## 4. Chromium harness (0001, 0002)
Checked at their own commits with real Chrome 131 (Ed25519 enabled via the launcher flag), `CHROME_PATH` pointing at it. The harness has **14 checks**: the first is "frontend dev server reachable" and 13 are the UI trust/transfer flow. (Earlier reports said "13/13"; that count omitted the first check, and I had wrongly explained the extra PASS line as a summary line - corrected here.)

| Case | rev2 (0001, `f204110`) | rev3 (0002, `8a42873`) |
|---|---|---|
| normal | exit 0, 14/14 PASS, 0 UNEXPECTED | exit 0, 14/14 PASS, 0 UNEXPECTED |
| injected request to a nonexistent host | exit 0 (reports UNEXPECTED, by design) | **exit 1** (UNEXPECTED network failure + console error) |
| injected page error | exit 0 (reports UNEXPECTED) | **exit 1** |
| forced Chrome startup failure | exit 1 | exit 1 |
| orphan vite/broker processes after each case (+3 s) | 0 | 0 |

Expected failures are only requests positively identified as `fonts.googleapis.com` / `fonts.gstatic.com` (both HTTP >=400 responses and no-response failures are tracked). All VERIFIED LOCALLY. The 403s on the Google Fonts stylesheet are environmental; production still loads that font from Google at runtime (privacy/offline consideration, unchanged).

## 5. Integration CI job (0004) — NOT RUN IN GITHUB ACTIONS
Local checks only: dry-run and apply on pristine succeed; YAML parses (jobs: backend, frontend, android, integration, secrets, release-gate); `release-gate` needs `[backend, frontend, android, integration, secrets]`; `integration` has `timeout-minutes: 20` and `timeout 150` per suite; it installs both dependency sets, generates a dev TLS cert, builds the two esbuild bundles, then runs `browser-protocol-integration` and `trust-state-integration`. I extracted the job's `run` blocks and working directories from the committed YAML and executed them in order in a fresh checkout of `a3b206a`: all 5 steps exit 0, browser-protocol 11 PASS, trust-state 10 PASS (VERIFIED LOCALLY). Android static check 14/14, release-gate script PASS, secret audit PASS on a clean export of the committed tree. (The audit fails inside a tree where the dev cert was generated; in CI the `secrets` job is a separate runner with a separate checkout and never generates a cert, so this does not apply.)

Not covered by the job: `chromium-e2e` and `accounting-quota-reconnect` (the latter only runs in `ci.yml`); no artifacts are uploaded (suite output is in the Actions log). Without the cert step the suites hang instead of failing, because the spawned broker exits and the tests have no internal watchdog.

## 6. Verification matrix
| Item | Status |
|---|---|
| Pristine source hash, patch applicability, byte-identity, composition | VERIFIED LOCALLY |
| Five separate local commits + verified git bundle | VERIFIED LOCALLY (not pushed) |
| Direct-mode bypass on pristine RC2.4 (revoke, stop-all) | FAILED (reproduced) |
| Production default refuses direct mode; override explicit + warned; provider gate; positive control | VERIFIED LOCALLY |
| Mutation tests for broker gate, provider gate, warning | VERIFIED LOCALLY |
| Full backend suite with 0003 (exit 0; 433 passed in summarised suites) | VERIFIED LOCALLY |
| Exploit replay against fixed code in production mode with a real trusted provider | BLOCKED / NOT REPLAYED (refusal point verified; SOURCE-REVIEWED) |
| Chromium harness 0001/0002 (8 cases, 0 orphans) | VERIFIED LOCALLY |
| Integration job steps and suites (local simulation) | VERIFIED LOCALLY |
| Integration job running in GitHub Actions | BLOCKED |
| Pristine-baseline and per-commit GitHub Actions runs | BLOCKED |
| Android build, APK, ABI libraries, install, VPN/TUN, tun2socks, internet via Android | BLOCKED |
| Two-device / different-network / carrier NAT / reconnect | BLOCKED |
| Override in production re-opens the bypass if set | SOURCE-REVIEWED (open; recommendation 3.4) |
| `pod-config.json` tracked and rewritten by tests | SOURCE-REVIEWED + observed (low, open) |

## 7. Release decision
**BLOCKED — EXTERNAL VERIFICATION REQUIRED.** GitHub CI, Android build/APK, physical-device and two-device/different-network tests have not been executed, and RC2.4 as shipped still contains the direct-mode bypass until 0003 is deployed. The fix is not "deployed": it exists only in local commits and patches.

## 8. Exact steps to run it on GitHub (needs your authenticated access; never paste tokens into chat)
```bash
# 0. verify, then unpack the exact commits
echo "c577d043f6c477188548724198455dfaa042e6cb17a14cfacb4f570b7ad36618  getdanet-rc2.4-with-fixes.gitbundle" | sha256sum -c -
git clone -b main getdanet-rc2.4-with-fixes.gitbundle GetDaNet-Production && cd GetDaNet-Production
gh auth login                                  # local, interactive
git remote add origin git@github.com:<OWNER>/<REPO>.git
# 1. pristine baseline FIRST (Actions must be enabled on the repo)
git push origin 13dcce1fef5f82ad6b1ca5f5dacbee58eb706a99:refs/heads/main
RUN=$(gh run list --workflow=production.yml --branch main --limit 1 --json databaseId -q '.[0].databaseId')
gh run watch $RUN --exit-status
gh run view $RUN --json url,headSha,conclusion,createdAt,updatedAt,jobs > baseline-run.json
gh run view $RUN --log > baseline-full.log; gh run view $RUN --log-failed > baseline-failed.log
# 2. then one commit at a time, each its own run
for sha in 8ca1673fcc235545fbe9a52f963c35f448b3e492 f2041109a4410ff6e8cf8bd1522d95360a94cc49 8a42873a91fad40338377cc393f3a17012c03cda a3b206a110111f83a7648d4af42b92093fbfe2fa; do
  git push origin $sha:refs/heads/main; sleep 15
  RUN=$(gh run list --workflow=production.yml --branch main --limit 1 --json databaseId -q '.[0].databaseId')
  gh run watch $RUN --exit-status || true
  gh run view $RUN --json url,headSha,conclusion,jobs > run-$sha.json
  gh run view $RUN --log-failed > failed-$sha.log
done
# 3. artifacts and APK evidence (from the android job of the final run)
gh run download $RUN; find . -name '*.apk' -exec sha256sum {} \;
unzip -l $(find . -name '*.apk' | head -1) | grep -E 'lib/.*/libtun2socks\.so'
```
Send back: each run URL and head SHA, the `conclusion` of `backend`, `frontend`, `android`, `integration`, `secrets` and `release-gate`, the failed-step log for any failure, and the APK SHA-256 plus the `libtun2socks.so` ABI list. Expect the first failures, if any, in the `android` job (Go 1.26.3 + NDK native step, first compile of `GetDaNetVpnService.kt`). Do not claim CI coverage for the integration job until a run shows it executing.
