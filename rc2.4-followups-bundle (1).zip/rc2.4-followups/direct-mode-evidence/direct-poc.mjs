import tls from "tls";
import WebSocket from "ws";
import { AUTH_TOKEN, websocketTlsOptions } from "./shared.js";
import { loadOrCreateIdentity, signNonce, randomNonce } from "./identity.js";
import { createCredentialManager } from "./node-credential-manager.js";
const BROKER_URL = process.env.BROKER_URL, CODE = process.env.INVITE_CODE, DIR = process.env.WORKDIR;
const identity = loadOrCreateIdentity(`${DIR}/direct-b.json`);
const cm = createCredentialManager({ brokerUrl: BROKER_URL, role: "requester", identity, stateFile: `${DIR}/direct-b-cred.json` });
const ws = new WebSocket(BROKER_URL, websocketTlsOptions());
const t0 = Date.now(); const T = () => ((Date.now() - t0) / 1000).toFixed(1);
let bytes = 0, started = false, brokerMsgs = [];
const done = (code, msg) => { console.log(msg); try { ws.close(); } catch {} process.exit(code); };
ws.on("open", async () => { const token = await cm.get(); const nonce = randomNonce(); ws.send(JSON.stringify({ type: "hello", role: "requester", token, nonce, signature: signNonce(identity.privateKey, nonce), identityPublicKey: identity.publicKey })); });
ws.on("message", (raw, isBin) => {
  if (isBin) return; const m = JSON.parse(raw.toString()); brokerMsgs.push(m.type);
  if (m.type === "welcome") ws.send(JSON.stringify({ type: "redeem-invite", code: CODE }));
  if (m.type === "invite-redeemed") { console.log(`[${T()}s] invite redeemed, status=${m.status}`); setTimeout(() => ws.send(JSON.stringify({ type: "direct-request", streamId: 1, target: "codeload.github.com:443" })), 1500); }
  if (m.type === "direct-fail") done(2, `direct-request refused: ${m.message}`);
  if (m.type === "direct-ready" && !started) {
    started = true; console.log(`[${T()}s] direct-ready advertised ${m.host}:${m.port}`);
    const outer = tls.connect({ host: m.host, port: m.port, rejectUnauthorized: false }, () => {
      const inner = tls.connect({ socket: outer, servername: "codeload.github.com" }, () => {
        inner.write("GET /torvalds/linux/tar.gz/refs/tags/v6.6 HTTP/1.1\r\nHost: codeload.github.com\r\nConnection: close\r\n\r\n");
        console.log(`[${T()}s] DIRECT transfer started (bypasses broker)`);
      });
      inner.on("data", (d) => { bytes += d.length; });
      inner.on("error", (e) => console.log(`[${T()}s] inner error: ${e.message}`));
      inner.on("close", () => console.log(`[${T()}s] direct stream CLOSED at ${bytes} bytes`));
    });
    outer.on("error", (e) => console.log(`[${T()}s] outer error: ${e.message}`));
    let last = 0;
    const iv = setInterval(() => { console.log(`[${T()}s] bytes=${bytes} (+${bytes - last})`); last = bytes; }, 1000);
    setTimeout(() => { clearInterval(iv); done(0, `FINAL bytes=${bytes} at t=${T()}s`); }, 14000);
  }
});
ws.on("error", (e) => done(3, `ws error ${e.message}`));
setTimeout(() => done(4, "timeout before direct-ready"), 40000);
