# usage: source; case_run <label> <harness-file-relative-to-integration-tests> <inject: none|net|pageerror> <chrome: ok|bad> <run-id>
cd /tmp/wt-harness
export CHROME_PATH_OK=/opt/pw-browsers/chromium-1194/chrome-linux/chrome
procs() { ps -eo args | grep -E "[v]ite dev|[b]roker-server\.js" | wc -l; }
case_run() {
  local label="$1" h="$2" inj="$3" chrome="$4" id="$5" f="integration-tests/$2" log="/home/claude/ev2/harness-$1.log"
  if [ "$inj" != none ]; then
    python3 - "$f" "$inj" <<PY
import sys
s=open(sys.argv[1]).read(); a='  await pageA.goto(\`\${APP_URL}/settings\`, { waitUntil: "networkidle0" });'; assert a in s
inj={'net':'  await pageA.evaluate(() => fetch("https://nonexistent-host-getdanet.invalid/x").catch(() => {}));\n  await new Promise((r) => setTimeout(r, 500));','pageerror':'  await pageA.evaluate(() => { setTimeout(() => { throw new Error("injected page error"); }, 0); });\n  await new Promise((r) => setTimeout(r, 500));'}[sys.argv[2]]
open('integration-tests/inj.tmp.mjs','w').write(s.replace(a,a+'\n'+inj,1))
PY
    f="integration-tests/inj.tmp.mjs"
  fi
  local cp=$CHROME_PATH_OK; [ "$chrome" = bad ] && cp=/nonexistent/chrome
  CHROME_PATH=$cp timeout 120 node $f $id > $log 2>&1; local rc=$?
  rm -f integration-tests/inj.tmp.mjs; sleep 3
  printf "%-34s EXIT=%s | steps PASS=%s | expected-failed-requests=%s | UNEXPECTED lines=%s | orphans(+3s)=%s\n" "$label" "$rc" "$(grep -c '\] PASS' $log)" "$(grep -c '^expected (external font CDN' $log)" "$(grep -c '^UNEXPECTED' $log)" "$(procs)"
  grep -m3 -E "^UNEXPECTED|^FAIL —|FATAL" $log | cut -c1-150 | sed 's/^/      /'
}
