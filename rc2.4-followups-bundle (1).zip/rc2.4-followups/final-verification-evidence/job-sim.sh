set -eo pipefail
cd /tmp/wt-final
echo "::step:: Install backend and frontend dependencies"
(cd . && bash -e -c '(cd backend && npm ci)
(cd frontend && npm ci)
'); echo "   step exit=$?"
echo "::step:: Generate dev TLS certificate (CI-only, never committed)"
(cd . && bash -e -c 'bash backend/certs/generate-dev-cert.sh'); echo "   step exit=$?"
echo "::step:: Build browser-client bundles (esbuild)"
(cd integration-tests && bash -e -c 'mkdir -p ../frontend/.integration-build
npx --prefix ../frontend esbuild ../frontend/src/lib/getdanet/client.ts --bundle --format=esm --platform=neutral --outfile=../frontend/.integration-build/client-bundle.mjs --log-level=error
npx --prefix ../frontend esbuild ../frontend/src/lib/getdanet/trust-state.ts --bundle --format=esm --platform=neutral --outfile=../frontend/.integration-build/trust-state-bundle.mjs --log-level=error
'); echo "   step exit=$?"
echo "::step:: browser-protocol-integration"
(cd integration-tests && bash -e -c 'timeout 150 node browser-protocol-integration.mjs'); echo "   step exit=$?"
echo "::step:: trust-state-integration"
(cd integration-tests && bash -e -c 'timeout 150 node trust-state-integration.mjs'); echo "   step exit=$?"
