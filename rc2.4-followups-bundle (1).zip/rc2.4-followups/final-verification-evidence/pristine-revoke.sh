cd /tmp/cisim/GetDaNet-Production/backend
export NODE_TLS_REJECT_UNAUTHORIZED=0 BROKER_URL=wss://127.0.0.1:18581 PORT=18581 GETDANET_AUTO_APPROVE=1
L=/home/claude/ev2/pristine-revoke; mkdir -p $L; D=$(mktemp -d); mkfifo $D/in; exec 3<>$D/in
node broker-server.js > $L/broker.log 2>&1 & BP=$!; sleep 2
GETDANET_IDENTITY_FILE=$D/a.json GETDANET_CREDENTIAL_STATE=$D/ca.json node client-a.js <&3 > $L/provider.log 2>&1 & AP=$!; sleep 2
echo CREATE_INVITE >&3; sleep 1
export INVITE_CODE=$(grep -o "invite-created code=[A-Z0-9-]*" $L/provider.log | head -1 | cut -d= -f2) WORKDIR=$D
node direct-poc.tmp.mjs > $L/poc.log 2>&1 & PP=$!
for i in $(seq 1 40); do grep -q "DIRECT transfer started" $L/poc.log 2>/dev/null && break; sleep 0.5; done
sleep 4
TID=$(grep -o "trustId=[a-f0-9-]*" $L/provider.log | head -1 | cut -d= -f2)
echo "[orchestrator] sending REVOKE ${TID} to provider now" | tee -a $L/poc.log
echo "REVOKE $TID" >&3
wait $PP; echo "poc exit=$?"
echo "--- broker log (relevant)"; grep -i -E "direct|revok|terminat" $L/broker.log | cut -c1-200
kill $AP $BP 2>/dev/null; sleep 1
